/**
 * Aegis OS — hosted server
 *
 * Serves the OS frontend and backs it with real infrastructure:
 *   - /api/fs/*   real files on disk under ./userfiles
 *   - /api/kv/*   small JSON-file key/value store for settings, terminal
 *                 history, and custom music links (replaces the browser
 *                 storage APIs the artifact version had to use instead)
 *   - /proxy      a real server-side proxy for the Browser app
 *
 * No auth. If you deploy this somewhere public (not a private Codespace),
 * anyone who can reach it can read/write your files and use this as an
 * open web proxy. Keep it private, or add auth before exposing it.
 */

const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

const USERFILES_DIR = path.join(__dirname, 'userfiles');
const KV_DIR = path.join(__dirname, 'data', 'kv');

/* ---------------- default starter filesystem ---------------- */

function defaultTree() {
  return {
    type: 'folder',
    children: {
      Desktop: { type: 'folder', children: {} },
      Documents: {
        type: 'folder',
        children: {
          'todo.txt': { type: 'file', content: '- Try the terminal\n- Open Settings\n- Have fun\n' },
          'readme.md': {
            type: 'file',
            content:
              '# Aegis OS\n\nThis is the hosted build. Everything in here is a real file on disk under ' +
              '`./userfiles` on the server — edit it in Files, in the Terminal, or directly in your editor, ' +
              'and it shows up in both places.\n'
          }
        }
      },
      Downloads: { type: 'folder', children: { 'build.zip': { type: 'file', content: '' } } },
      Pictures: { type: 'folder', children: { 'wallpaper.png': { type: 'file', content: '' } } },
      Projects: { type: 'folder', children: { 'notes.txt': { type: 'file', content: 'Project notes go here.\n' } } },
      Assets: { type: 'folder', children: {} },
      Backups: { type: 'folder', children: {} },
      userfiles: { type: 'folder', children: {} }
    }
  };
}

function ensureDirs() {
  fs.mkdirSync(USERFILES_DIR, { recursive: true });
  fs.mkdirSync(KV_DIR, { recursive: true });
  if (fs.readdirSync(USERFILES_DIR).length === 0) {
    writeTreeToDisk(defaultTree(), USERFILES_DIR);
  }
}

/* ---------------- tree <-> real files on disk ---------------- */

function readTreeFromDisk(dirPath) {
  const node = { type: 'folder', children: {} };
  let entries = [];
  try {
    entries = fs.readdirSync(dirPath, { withFileTypes: true });
  } catch (e) {
    return node;
  }
  for (const entry of entries) {
    if (entry.name.startsWith('.')) continue;
    const fullPath = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      node.children[entry.name] = readTreeFromDisk(fullPath);
    } else {
      let content = '';
      try {
        content = fs.readFileSync(fullPath, 'utf-8');
      } catch (e) {
        /* unreadable (binary, permissions, etc.) — represent as empty */
      }
      node.children[entry.name] = { type: 'file', content };
    }
  }
  return node;
}

function safeName(name) {
  // keep this to simple filenames — no path traversal, no separators
  return String(name).replace(/[\/\\]/g, '_').replace(/^\.+/, '_');
}

function writeChildrenToDisk(node, dirPath) {
  for (const [name, child] of Object.entries(node.children || {})) {
    const fullPath = path.join(dirPath, safeName(name));
    if (child && child.type === 'folder') {
      fs.mkdirSync(fullPath, { recursive: true });
      writeChildrenToDisk(child, fullPath);
    } else {
      fs.writeFileSync(fullPath, (child && child.content) || '');
    }
  }
}

function writeTreeToDisk(node, dirPath) {
  fs.rmSync(dirPath, { recursive: true, force: true });
  fs.mkdirSync(dirPath, { recursive: true });
  writeChildrenToDisk(node, dirPath);
}

ensureDirs();

app.use(express.json({ limit: '20mb' }));
app.use(express.static(path.join(__dirname, 'public')));

/* ---------------- real filesystem API ---------------- */

app.get('/api/fs/tree', (req, res) => {
  res.json(readTreeFromDisk(USERFILES_DIR));
});

app.put('/api/fs/tree', (req, res) => {
  try {
    writeTreeToDisk(req.body, USERFILES_DIR);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/fs/reset', (req, res) => {
  try {
    writeTreeToDisk(defaultTree(), USERFILES_DIR);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/* ---------------- generic key/value store ---------------- */
/* settings, terminal history, custom music links — small JSON blobs,   */
/* not user-facing "files", so these live under ./data/kv instead of    */
/* mixing into the real userfiles tree.                                 */

function kvPath(key) {
  const safe = Buffer.from(String(key)).toString('base64url');
  return path.join(KV_DIR, safe + '.json');
}

app.get('/api/kv/:key', (req, res) => {
  const file = kvPath(req.params.key);
  if (!fs.existsSync(file)) return res.status(404).json({ error: 'not found' });
  const value = fs.readFileSync(file, 'utf-8');
  res.json({ key: req.params.key, value });
});

app.put('/api/kv/:key', (req, res) => {
  try {
    fs.writeFileSync(kvPath(req.params.key), req.body && req.body.value != null ? req.body.value : '');
    res.json({ key: req.params.key, value: req.body.value });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/kv/:key', (req, res) => {
  const file = kvPath(req.params.key);
  if (fs.existsSync(file)) fs.unlinkSync(file);
  res.json({ deleted: true });
});

/* ---------------- real server-side proxy for the Browser app ---------------- */
/* Fetches the target server-side and serves it back same-origin, which is     */
/* what actually gets around X-Frame-Options — the browser only ever checks    */
/* headers on the response it received (ours), not the original site's.       */
/* An injected <base> tag makes relative-path CSS/JS/images resolve against    */
/* the real site and load directly from it, not through this proxy.            */

app.get('/proxy', async (req, res) => {
  const target = req.query.url;
  if (!target || !/^https?:\/\//i.test(String(target))) {
    return res.status(400).send('Missing or invalid "url" query parameter.');
  }
  try {
    const upstream = await fetch(target, {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; AegisOSProxy/1.0)' },
      redirect: 'follow'
    });
    const contentType = upstream.headers.get('content-type') || 'application/octet-stream';
    const buffer = Buffer.from(await upstream.arrayBuffer());

    res.status(upstream.status);
    res.set('Content-Type', contentType);
    // Deliberately not forwarding the upstream's X-Frame-Options / CSP —
    // stripping those is the entire point of this route.

    if (contentType.includes('text/html')) {
      let html = buffer.toString('utf-8');
      const baseTag = '<base href="' + target.replace(/"/g, '&quot;') + '">';
      html = /<head[^>]*>/i.test(html)
        ? html.replace(/<head[^>]*>/i, (m) => m + baseTag)
        : baseTag + html;
      return res.send(html);
    }
    res.send(buffer);
  } catch (err) {
    res.status(502).send('Proxy fetch failed: ' + err.message);
  }
});

/* ---------------- SPA fallback ---------------- */

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log('Aegis OS running at http://localhost:' + PORT);
});
