# Aegis OS — hosted build

The same OS demo, now running with a real backend instead of browser-storage
workarounds.

## Run it in a Codespace

1. Push this folder to a GitHub repo (or open it directly if it's already one).
2. Open it in a Codespace. The devcontainer runs `npm install` for you and
   starts the server automatically; Codespaces will forward port 3000 and
   offer to open it in your browser.
3. If it doesn't start on its own: `npm start`, then open the forwarded port.

## Run it anywhere else

```
npm install
npm start
```

Then open http://localhost:3000

## What's actually real now (vs. the browser-only version)

- **Files app / Terminal** read and write actual files under `./userfiles/`
  on this machine. Delete something in Files, it's gone from disk. Create a
  file in the Terminal, it shows up in Files. Restart the server, it's still
  there.
- **System Wipe** really deletes `./userfiles/` and regenerates the starter
  tree.
- **Browser app**'s "Full Page" mode routes through `/proxy`, a plain Express
  route on this same server — it fetches the target page itself, strips the
  headers that block iframe embedding, and serves the result back
  same-origin. No third-party service, no shared rate limit.
- Settings, terminal history, and any custom music links you add are stored
  as small JSON files under `./data/kv/`.

## What's still limited, on purpose

- `/proxy` is a straightforward implementation — fetch, strip headers, inject
  a `<base>` tag so relative-path assets resolve correctly. It's not a
  hardened production proxy. Sites with frame-busting JavaScript, or APIs
  that reject cross-origin requests, can still misbehave.
- **No authentication.** Anyone who can reach this server can read/write
  everything under `userfiles/` and use `/proxy` as an open relay. Fine for a
  private Codespace you're the only one with access to; not fine if you
  deploy it somewhere public without adding auth first.
- `userfiles/` and `data/` are gitignored on purpose, so a fresh clone/rebuild
  always starts from the clean default tree rather than committing your demo
  files to source control.
